# ConVia Datenraum — Geschützter Zugang & Auswertung

Bausteine, um den ConVia-Datenraum in deine bestehende Executive-Diagnostics-Suite
(`diagnostic-suite.de`) zu integrieren: Magic-Link-Zugang, festes Enddatum,
Verschleierung der Adresse, automatische Authentifizierung und volles
Verhaltens-Tracking mit Auswerte-Ansicht.

## Was du bekommst

| Datei | Zweck | Andocken nötig? |
|---|---|---|
| `1_schema_additions.prisma` | DB-Modelle für Tokens + Events | ja (workspace-Feld) |
| `2_tracking_snippet.html` | Sendet Events an den Server | nein — copy-paste in HTML |
| `3_server_routes.ts` | Einlösung, Event-Empfang, Link-Erstellung | ja (Prisma, Cookies, RBAC) |
| `4_evaluation_page.tsx` | Auswerte-Dashboard pro Kandidat | ja (Daten-Endpunkt, RBAC) |
| `5_REPLIT_AGENT_PROMPT.md` | Anleitung für den Replit-Agenten | — |

## Empfohlener Weg (dein Setup: Replit, Eigen-Deployment)

1. Lade alle Dateien **und** `ConVia_Datenraum.html` in dein Replit-Projekt.
2. Öffne den Replit-Agenten, füge den Inhalt von `5_REPLIT_AGENT_PROMPT.md` ein.
3. Der Agent verdrahtet die `>>> ANPASSEN <<<`-Stellen mit deinem echten Code.
4. Migration anwenden, Enddatum-Testlink erzeugen, durchklicken.

## Wie es für den Kandidaten aussieht

1. Du erzeugst im Admin-Bereich einen Link mit Label + Enddatum.
2. Du schickst ihm `https://www.diagnostic-suite.de/dr/<token>`.
3. Klick → Datenraum startet sofort, ohne Passworteingabe.
4. Sein Verhalten (Suche, geöffnete Dokumente, Verweildauer, Notizen) landet
   serverseitig in der DB.
5. Nach dem Enddatum ist der Link tot.
6. Du öffnest die Auswerte-Seite und siehst Timeline + Statistiken.

## Ehrliche Grenzen

- **URL-Weitergabe:** Der Token ist nicht ratbar, aber wer ihn hat, kommt rein
  (bis zum Enddatum). Für strengeren Schutz: Einmal-Links (`multiUse=false`) oder
  Bindung an die E-Mail des Kandidaten.
- **Tracking ist clientseitig ausgelöst:** Bei deaktiviertem JavaScript oder
  hartem Tab-Schließen können einzelne End-Events fehlen. Heartbeat + sendBeacon
  mildern das, garantieren aber keine 100% Vollständigkeit.
- **Datenschutz:** Es werden echte Verhaltensdaten erfasst. Kläre, ob ein
  Einwilligungshinweis nötig ist (dein Consent-System kann das abbilden).
- **Schema-Andocken:** Die als copy-paste markierten Teile laufen sofort; die
  schema-abhängigen Teile brauchen das Andocken durch den Replit-Agenten oder dich.
